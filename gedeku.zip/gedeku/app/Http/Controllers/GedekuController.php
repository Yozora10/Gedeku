<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Message;
use Illuminate\Http\Request;

class GedekuController extends Controller
{
    // Method untuk menampilkan halaman utama
    public function home()
    {
        $data = [
            'title' => 'Rumah'
        ];

        return view("home", compact('data'));
    }

    // Method untuk menampilkan halaman tentang kami
    public function aboutUs()
    {
        $data = [
            'title' => 'Tentang Kami'
        ];

        return view("aboutUs", compact('data'));
    }

    // Method untuk menampilkan halaman produk kami
    public function ourProduct()
    {
        $data = [
            'title' => 'Produk Kami'
        ];

        return view("ourProduct", compact('data'));
    }

    // Method untuk menampilkan halaman ulasan
    public function review()
    {
        $data = [
            'title' => 'Ulasan'
        ];

        return view("review", compact('data'));
    }

    // Method untuk menampilkan halaman pertanyaan umum
    public function faq()
    {
        $data = [
            'title' => 'Pertanyaan Umum'
        ];

        return view("faq", compact('data'));
    }

    // Method untuk menyimpan pesan yang dikirim oleh pengguna
    public function inputMessage(Request $request)
    {
        // Validasi data yang diterima dari request
        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'phone' => 'required',
            'company' => 'required',
            'message' => 'required'
        ]);

        // Simpan pesan ke database menggunakan model Message
        Message::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'phone' => $request['phone'],
            'company' => $request['company'],
            'message' => $request['message']
        ]);

        // Redirect kembali ke halaman utama dengan pesan sukses
        return redirect('/')->with("inputMessageSuccess", "Berhasil mengirim pesan baru!");
    }
}
