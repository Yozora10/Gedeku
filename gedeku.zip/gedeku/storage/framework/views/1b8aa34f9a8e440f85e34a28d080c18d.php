<nav>
    <!-- Elemen navigasi utama -->
    <ul class="link-left">
        <!-- Daftar tautan di sisi kiri -->
        <li>
            <a href="/" <?php if($data['title'] === 'Rumah'): ?> class="nav-link-active" <?php endif; ?>>RUMAH</a>
            <!-- Tautan ke halaman beranda, menambahkan kelas 'nav-link-active' jika judul halaman saat ini adalah 'Rumah' -->
        </li>
        <li>
            <a href="/aboutUs" <?php if($data['title'] === 'Tentang Kami'): ?> class="nav-link-active" <?php endif; ?>>TENTANG KAMI</a>
            <!-- Tautan ke halaman Tentang Kami, menambahkan kelas 'nav-link-active' jika judul halaman saat ini adalah 'Tentang Kami' -->
        </li>
        <li>
            <a href="/ourProduct" <?php if($data['title'] === 'Produk Kami'): ?> class="nav-link-active" <?php endif; ?>>PRODUK KAMI</a>
            <!-- Tautan ke halaman Produk Kami, menambahkan kelas 'nav-link-active' jika judul halaman saat ini adalah 'Produk Kami' -->
        </li>
    </ul>
    <ul class="link-right">
        <!-- Daftar tautan di sisi kanan -->
        <li>
            <a href="/review" <?php if($data['title'] === 'Ulasan'): ?> class="nav-link-active" <?php endif; ?>>ULASAN</a>
            <!-- Tautan ke halaman Ulasan, menambahkan kelas 'nav-link-active' jika judul halaman saat ini adalah 'Ulasan' -->
        </li>
        <li>
            <a href="/faq" <?php if($data['title'] === 'Pertanyaan Umum'): ?> class="nav-link-active" <?php endif; ?>>PERTANYAAN UMUM</a>
            <!-- Tautan ke halaman Pertanyaan Umum, menambahkan kelas 'nav-link-active' jika judul halaman saat ini adalah 'Pertanyaan Umum' -->
        </li>
        <li>
            <a target="_blank" href="https://id.shp.ee/UZKUgJR" class="nav-link-active">
                <i class="fa-solid fa-cart-shopping"></i>
                <!-- Tautan ke halaman belanja eksternal dengan ikon keranjang belanja -->
            </a>
        </li>
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\gedeku\resources\views/components/navbar.blade.php ENDPATH**/ ?>