<style>
    .footer-content {
        display: flex;
        align-items: center;
        padding: 20px;
        font-size: 20px;
        gap: 40px;
        /* Memberikan jarak antara logo dan info */
    }

    .footer-logo {
        width: 30%;
        border-right: 3px solid black
    }

    .footer-logo img {
        width: 100%;
    }

    .footer-info {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .footer-item {
        display: flex;
        align-items: center;
        gap: 40px;
        margin-bottom: 5px;
    }

    .footer-item i {
        font-size: 24px;
    }

    .footer-map {
        display: flex;
        align-items: center;
        gap: 40px;
        margin-bottom: 5px;
    }

    /* Media Queries for Responsive Design */
    @media (max-width: 768px) {
        .footer-content {
            flex-direction: column;
            align-items: center;
            text-align: center;
            gap: 20px;
            /* Mengurangi jarak pada tampilan lebih kecil */
        }

        .footer-logo img {
            width: 50%;
            /* Menyesuaikan ukuran logo pada tampilan lebih kecil */
        }

        .footer-info {
            align-items: center;
        }
    }
</style>

<footer style="background-image: url('<?php echo e(asset('img/backgroundWallpaper.png')); ?>'); padding: 20px 0;">
    <!-- Footer dengan latar belakang gambar dan padding atas-bawah 20px -->
    <div class="footer-content">
        <div class="footer-logo">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo">
            <!-- Gambar logo -->
        </div>
        <div class="footer-info">
            <div class="footer-item">
                <i class="fa-solid fa-phone"></i>
                <!-- Ikon telepon dari FontAwesome -->
                <span>+62 813-6376-4625</span>
                <!-- Nomor telepon -->
            </div>
            <div class="footer-item">
                <i class="fa-brands fa-instagram"></i>
                <!-- Ikon Instagram dari FontAwesome -->
                <span>@gedeku_keripik_gonggong</span>
                <!-- Akun Instagram -->
            </div>
            <div class="footer-item">
                <i class="fa-solid fa-location-dot"></i>
                <!-- Ikon lokasi dari FontAwesome -->
                <span>Kav. Flamboyan Blok B No. 16 Sagulung, Batam, Riau,<br>Indonesia 29451</span>
                <!-- Alamat lengkap dengan pemisah baris <br> -->
            </div>
        </div>
        <div class="footer-map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.170716475865!2d103.9620283!3d1.0323374!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31d98d86eeaa5599%3A0x92d07d6e03b00706!2sOleh%20oleh%20Batam%20Gedeku!5e0!3m2!1sid!2sid!4v1718105375226!5m2!1sid!2sid" width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\gedeku\resources\views/components/footer.blade.php ENDPATH**/ ?>