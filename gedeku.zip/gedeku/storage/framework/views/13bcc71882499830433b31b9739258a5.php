<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Menetapkan karakter encoding untuk dokumen HTML -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Menetapkan viewport agar layout menjadi responsif pada berbagai perangkat -->
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Memastikan kompatibilitas dengan IE -->
    <title>Gedeku - <?php echo e($data['title']); ?></title>
    <!-- Menetapkan judul halaman dinamis berdasarkan data yang diterima -->
    <link rel="stylesheet" href="<?php echo e(asset('css/navbarStyle.css')); ?>">
    <!-- Memuat stylesheet untuk navbar -->
    <link rel="stylesheet" href="<?php echo e(asset('css/formStyle.css')); ?>">
    <!-- Memuat stylesheet untuk form -->
    <?php if($data['title'] === 'Rumah'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/homeStyle.css')); ?>">
        <!-- Memuat stylesheet khusus untuk halaman Rumah -->
    <?php elseif($data['title'] === 'Tentang Kami'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/aboutUsStyle.css')); ?>">
        <!-- Memuat stylesheet khusus untuk halaman Tentang Kami -->
    <?php elseif($data['title'] === 'Produk Kami'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/ourProductStyle.css')); ?>">
        <!-- Memuat stylesheet khusus untuk halaman Produk Kami -->
    <?php elseif($data['title'] === 'Ulasan'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/reviewStyle.css')); ?>">
        <!-- Memuat stylesheet khusus untuk halaman Ulasan -->
    <?php elseif($data['title'] === 'Pertanyaan Umum'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/faqStyle.css')); ?>">
        <!-- Memuat stylesheet khusus untuk halaman Pertanyaan Umum -->
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Memuat stylesheet untuk ikon FontAwesome -->
</head>

<body style="background-image: url('<?php echo e(asset('img/bg-body.png')); ?>')">
    <!-- Mengatur background gambar untuk body dari path yang disediakan oleh Laravel asset helper -->
    <?php echo $__env->make('components/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Menyertakan komponen navbar -->
    <?php echo $__env->yieldContent('main'); ?>
    <!-- Bagian konten utama yang dapat diubah pada halaman-halaman yang menggunakan layout ini -->
    <?php echo $__env->make('components/form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Menyertakan komponen form -->
    <?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Menyertakan komponen footer -->
</body>

</html>
<?php /**PATH C:\xampp\htdocs\gedeku\resources\views/layouts/main.blade.php ENDPATH**/ ?>