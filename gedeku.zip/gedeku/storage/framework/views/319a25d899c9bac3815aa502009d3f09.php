

<?php $__env->startSection('main'); ?>
    <div class="wallpaper" style="background-image: url('<?php echo e(asset('img/backgroundWallpaper.png')); ?>')">
        <!-- Bagian wallpaper dengan gambar latar belakang -->
        <div class="wallpaper-content">
            <div class="left">
                <img src="<?php echo e(asset('img/paket.png')); ?>" alt="Paket">
                <!-- Gambar paket di sisi kiri -->
            </div>
            <div class="right">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo">
                <!-- Logo di sisi kanan atas -->
                <div class="wp-title">
                    <h2>KERIPIK KARI GONGGONG</h2>
                    <!-- Judul produk -->
                    <a href="ourProduct">Tampilkan Lainnya</a>
                    <!-- Link untuk menampilkan lebih banyak -->
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <center>
            <!-- Bagian konten -->
            <div class="content-section">
                <div class="left">
                    <h1>Rasakan Sensasi<br>keripik kari Gonggong<br>Yang Auntentik</h1>
                    <!-- Judul konten -->
                </div>
                <div class="right">
                    <img src="<?php echo e(asset('img/gonggong.png')); ?>" alt="Gonggong">
                    <!-- Gambar di sisi kanan -->
                </div>
            </div>
        </center>
        <br><br><br><br>
        <center>
            <!-- Bagian konten berikutnya -->
            <div class="content-section">
                <div class="left">
                    <img src="<?php echo e(asset('img/product-single.png')); ?>" alt="Gonggong">
                    <!-- Gambar di sisi kiri -->
                </div>
                <div class="right">
                    <h3>
                        Selamat datang di Gedeku! Temukan kelezatan sejati<br>
                        dengan produk unggulan kami, Keripik Kari<br>
                        Gonggong. Dibuat dengan bahan-bahan berkualitas<br>
                        dan cita rasa kari yang autentik, setiap gigitan<br>
                        keripik kami akan membawa Anda dalam perjalanan<br>
                        rasa yang tak terlupakan. Sajikan untuk dinikmati<br>
                        bersama keluarga dan teman, atau nikmati sebagai<br>
                        camilan istimewa di waktu santap Anda. Mulailah<br>
                        pengalaman rasa baru Anda dengan keripik kari<br>
                        gonggong kami hari ini!
                    </h3>
                    <!-- Deskripsi produk -->
                    <center>
                        <a target="_blank" href="https://wa.me/c/6281363764625" class="pesanWhatsapp"><i
                                class="fa-brands fa-whatsapp"></i> Pesan
                            Sekarang</a>
                        <!-- Link pesan Whatsapp -->
                    </center>
                </div>
            </div>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gedeku\resources\views/home.blade.php ENDPATH**/ ?>