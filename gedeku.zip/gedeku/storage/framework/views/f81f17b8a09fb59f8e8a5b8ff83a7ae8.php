

<?php $__env->startSection('main'); ?>
    <!-- Menggunakan layout utama dari 'layouts/main' -->

    <div class="wallpaper" style="background-image: url('<?php echo e(asset('img/gonggong.png')); ?>')"></div>
    <!-- Div dengan background gambar yang diambil dari path yang disediakan oleh Laravel asset helper -->

    <div class="container">
        <!-- Div container untuk mengatur tata letak konten -->
        <center>
            <!-- Center untuk meratakan isi ke tengah -->
            <h1>About Us</h1>
            <!-- Judul halaman -->
            <p class="aboutUsDesc">
                Gonggong adalah sebuah perusahaan yang<br>
                memproduksi makanan khas daerah Melayu yang dikemas<br>
                dengan berbagai ukuran, yang dibuat dengan rempah-<br>rempah dan olahan seafood.
                <!-- Deskripsi tentang Gonggong dengan pemisah baris <br> untuk format teks -->
            </p>
            <p class="aboutUsDesc">
                Gedeku mulai beroprasi sejak 2007 dengan<br>
                penjualan awal melalui door to door. Prospek<br>
                pengembangan usaha ini sangat menjanjikan makanan yang<br>
                memiliki cita rasa yang khas dengan olahan-olahan seafood<br>
                yaitu, udang, gonggong, cumi-cumi, ikan dan lain-lain.
                <!-- Deskripsi tentang Gonggong dengan pemisah baris <br> untuk format teks -->
            </p>
            <p class="aboutUsDesc">
                Produk Gedeku dapat dijumpai dibeberapa toko<br>
                retail, outlet oleh-oleh di Batam atau bisa juga melakukkan<br>
                order delievery langsung ke marketing kami.
                <!-- Deskripsi tentang Gonggong dengan pemisah baris <br> untuk format teks -->
            </p>
            <br><br><br>
            <!-- Pemisah baris untuk memberikan jarak antara deskripsi dan tombol -->
            <div class="button-container">
                <!-- Div untuk mengatur tata letak tombol -->
                <button class="visimisiBtn">
                    Visi<br><br>
                    "Menjadi Perusahaan pengolahan<br>makanan khas daerah dalam<br>pengembangan produk daerah".
                </button>
                <!-- Tombol untuk visi -->
                <button class="visimisiBtn">
                    Misi<br><br>
                    1. Mengenalkan keripik yang<br>menggunakan olahan seafood.<br>
                    2. Menjadi makanan oleh-oleh dari<br>Provinsi Kepulauan Riau.
                </button>
                <!-- Tombol untuk misi -->
            </div>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gedeku\resources\views/aboutUs.blade.php ENDPATH**/ ?>