@extends('layouts/main')

@section('main')
    <div class="wallpaper" style="background-image: url('{{ asset('img/backgroundWallpaper.png') }}')">
        <!-- Gambar latar belakang untuk halaman -->
        <div class="wallpaper-content">
            <img src="{{ asset('img/logo.png') }}" alt="Logo" class="logo">
            <!-- Logo -->
            <center>
                <img src="{{ asset('img/paket.png') }}" alt="Paket">
            </center>
            <!-- Gambar paket -->
        </div>
    </div>
    <div class="container">
        <!-- Konten ulasan -->
        <div class="left">
            <img src="{{ asset('img/review1.png') }}" alt="Review">
        </div>
        <!-- Ulasan 1 -->
        <div class="right">
            <img src="{{ asset('img/review2.png') }}" alt="Review">
        </div>
        <!-- Ulasan 2 -->
        <div class="left">
            <img src="{{ asset('img/review3.png') }}" alt="Review">
        </div>
        <!-- Ulasan 3 -->
        <div class="right">
            <img src="{{ asset('img/review4.png') }}" alt="Review">
        </div>
        <!-- Ulasan 4 -->
        <div class="left">
            <img src="{{ asset('img/review5.png') }}" alt="Review">
        </div>
        <!-- Ulasan 5 -->
    </div>
    <!-- Penutup konten ulasan -->
@endsection
