<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Menetapkan karakter encoding untuk dokumen HTML -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Menetapkan viewport agar layout menjadi responsif pada berbagai perangkat -->
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Memastikan kompatibilitas dengan IE -->
    <title>Gedeku - {{ $data['title'] }}</title>
    <!-- Menetapkan judul halaman dinamis berdasarkan data yang diterima -->
    <link rel="stylesheet" href="{{ asset('css/navbarStyle.css') }}">
    <!-- Memuat stylesheet untuk navbar -->
    <link rel="stylesheet" href="{{ asset('css/formStyle.css') }}">
    <!-- Memuat stylesheet untuk form -->
    @if ($data['title'] === 'Rumah')
        <link rel="stylesheet" href="{{ asset('css/homeStyle.css') }}">
        <!-- Memuat stylesheet khusus untuk halaman Rumah -->
    @elseif($data['title'] === 'Tentang Kami')
        <link rel="stylesheet" href="{{ asset('css/aboutUsStyle.css') }}">
        <!-- Memuat stylesheet khusus untuk halaman Tentang Kami -->
    @elseif($data['title'] === 'Produk Kami')
        <link rel="stylesheet" href="{{ asset('css/ourProductStyle.css') }}">
        <!-- Memuat stylesheet khusus untuk halaman Produk Kami -->
    @elseif($data['title'] === 'Ulasan')
        <link rel="stylesheet" href="{{ asset('css/reviewStyle.css') }}">
        <!-- Memuat stylesheet khusus untuk halaman Ulasan -->
    @elseif($data['title'] === 'Pertanyaan Umum')
        <link rel="stylesheet" href="{{ asset('css/faqStyle.css') }}">
        <!-- Memuat stylesheet khusus untuk halaman Pertanyaan Umum -->
    @endif
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Memuat stylesheet untuk ikon FontAwesome -->
</head>

<body style="background-image: url('{{ asset('img/bg-body.png') }}')">
    <!-- Mengatur background gambar untuk body dari path yang disediakan oleh Laravel asset helper -->
    @include('components/navbar')
    <!-- Menyertakan komponen navbar -->
    @yield('main')
    <!-- Bagian konten utama yang dapat diubah pada halaman-halaman yang menggunakan layout ini -->
    @include('components/form')
    <!-- Menyertakan komponen form -->
    @include('components/footer')
    <!-- Menyertakan komponen footer -->
</body>

</html>
