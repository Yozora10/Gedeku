@extends('layouts/main')

@section('main')
    <div class="wallpaper" style="background-image: url('{{ asset('img/backgroundWallpaper.png') }}')">
        <!-- Bagian wallpaper dengan gambar latar belakang -->
        <div class="wallpaper-content">
            <div class="left">
                <img src="{{ asset('img/paket.png') }}" alt="Paket">
                <!-- Gambar paket di sisi kiri -->
            </div>
            <div class="right">
                <div class="wp-title">
                    <h1>FREQUENTLY<br>ASKED<br>QUESTION</h1>
                    <!-- Judul FAQ di sisi kanan -->
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="card-faq">
            <center>
                <!-- Bagian tabel FAQ -->
                <table cellpadding="0" cellspacing="0" class="table-faq">
                    <!-- Pertanyaan pertama -->
                    <tr>
                        <th>
                            1. APA ITU KERIPIK KARI GONGGONG?
                        </th>
                        <td>
                            <button class="toggle-content"><i class="fa-solid fa-chevron-down"></i></button>
                            <!-- Tombol untuk membuka/menutup jawaban -->
                        </td>
                    </tr>
                    <tr class="faq-content" style="display: none;">
                        <td colspan="2">
                            <center>
                                Kerupuk kari gonggong adalah sejenis kerupuk yang terbuat dari bahan utama berupa gonggong
                                yang diolah dengan bumbu kari yang khas. Kerupuk ini menjadi hidangan lezat dan unik dengan
                                cita rasa kari yang menggugah selera.
                                <!-- Jawaban untuk pertanyaan pertama -->
                            </center>
                        </td>
                    </tr>
                    <!-- Pertanyaan kedua -->
                    <tr>
                        <th>
                            2. BAGAIMANA CARA MEMESAN KERUPUK KARI GONGGONG?
                        </th>
                        <td>
                            <button class="toggle-content"><i class="fa-solid fa-chevron-down"></i></button>
                        </td>
                    </tr>
                    <tr class="faq-content" style="display: none;">
                        <td colspan="2">
                            <center>
                                Anda dapat memesan kerupuk kari gonggong kami melalui situs web kami dengan menambahkannya
                                ke keranjang belanja dan mengikuti proses pembayaran yang mudah. Kami juga menerima
                                pemesanan melalui telepon atau email.
                                <!-- Jawaban untuk pertanyaan kedua -->
                            </center>
                        </td>
                    </tr>
                    <!-- Pertanyaan ketiga -->
                    <tr>
                        <th>
                            3. APAKAH KERUPUK KARI GONGGONG TERSEDIA<br>DALAM BERBAGAI UKURAN KEMASAN?
                        </th>
                        <td>
                            <button class="toggle-content"><i class="fa-solid fa-chevron-down"></i></button>
                        </td>
                    </tr>
                    <tr class="faq-content" style="display: none;">
                        <td colspan="2">
                            <center>
                                Ya, kami menawarkan kerupuk kari gonggong dalam berbagai ukuran kemasan yang dapat
                                disesuaikan dengan kebutuhan Anda, mulai dari ukuran kecil untuk konsumsi pribadi hingga
                                ukuran besar untuk acara khusus atau toko kelontong.
                                <!-- Jawaban untuk pertanyaan ketiga -->
                            </center>
                        </td>
                    </tr>
                    <!-- Pertanyaan keempat -->
                    <tr>
                        <th>
                            4. APAKAH KERUPUK KARI GONGGONG AMAN<br>DIKONSUMSI?
                        </th>
                        <td>
                            <button class="toggle-content"><i class="fa-solid fa-chevron-down"></i></button>
                        </td>
                    </tr>
                    <tr class="faq-content" style="display: none;">
                        <td colspan="2">
                            <center>
                                Ya, kerupuk kari gonggong kami diproduksi dengan standar kebersihan dan keamanan pangan yang
                                ketat. Kami menggunakan bahan-bahan berkualitas tinggi dan proses produksi yang higienis
                                untuk memastikan produk kami aman untuk dikonsumsi.
                                <!-- Jawaban untuk pertanyaan keempat -->
                            </center>
                        </td>
                    </tr>
                    <!-- Pertanyaan kelima -->
                    <tr>
                        <th>
                            5. BERAPA LAMA MASA SIMPAN KERUPUK KARI<br>GONGGONG?
                        </th>
                        <td>
                            <button class="toggle-content"><i class="fa-solid fa-chevron-down"></i></button>
                        </td>
                    </tr>
                    <tr class="faq-content" style="display: none;">
                        <td colspan="2">
                            <center>
                                Masa simpan kerupuk kari gonggong kami dapat bervariasi tergantung pada kondisi penyimpanan.
                                Namun, dalam kondisi penyimpanan yang tepat, biasanya produk kami dapat bertahan hingga
                                beberapa bulan.

                                <!-- Jawaban untuk pertanyaan kelima -->
                            </center>
                        </td>
                    </tr>
                    <!-- Pertanyaan keenam -->
                    <tr>
                        <th>
                            6. APAKAH ADA OPSI PENGIRIMAN UNTUK<br>PEMBELIAN BESAR?
                        </th>
                        <td>
                            <button class="toggle-content"><i class="fa-solid fa-chevron-down"></i></button>
                        </td>
                    </tr>
                    <tr class="faq-content" style="display: none;">
                        <td colspan="2">
                            <center>
                                Ya, kami menyediakan layanan pengiriman untuk pembelian besar. Silakan hubungi tim dukungan
                                pelanggan kami untuk informasi lebih lanjut tentang opsi pengiriman dan harga grosir.
                                <!-- Jawaban untuk pertanyaan keenam -->
                            </center>
                        </td>
                    </tr>
                    <!-- Pertanyaan ketujuh -->
                    <tr>
                        <th>
                            7. APAKAH ADA OPSI PENGIRIMAN INTERNASIONAL?
                        </th>
                        <td>
                            <button class="toggle-content"><i class="fa-solid fa-chevron-down"></i></button>
                        </td>
                    </tr>
                    <tr class="faq-content" style="display: none;">
                        <td colspan="2">
                            <center>
                                Saat ini, kami hanya menawarkan pengiriman di dalam negeri. Namun, kami terus mengevaluasi
                                opsi pengiriman internasional untuk masa mendatang.

                                <!-- Jawaban untuk pertanyaan ketujuh -->
                            </center>
                        </td>
                    </tr>
                    <!-- Pertanyaan kedelapan -->
                    <tr>
                        <th>
                            8. BAGAIMANA JIKA SAYA TIDAK PUAS DENGAN<br>PRODUK YANG SAYA TERIMA?
                        </th>
                        <td>
                            <button class="toggle-content"><i class="fa-solid fa-chevron-down"></i></button>
                        </td>
                    </tr>
                    <tr class="faq-content" style="display: none;">
                        <td colspan="2">
                            <center>
                                Kepuasan pelanggan adalah prioritas utama kami. Jika Anda tidak puas dengan produk yang Anda
                                terima, silakan hubungi kami dalam waktu 7 hari setelah menerima pesanan Anda untuk
                                mendapatkan penggantian atau pengembalian dana.
                                <!-- Jawaban untuk pertanyaan kedelapan -->
                            </center>
                        </td>
                    </tr>
                    <!-- Pertanyaan kesembilan -->
                    <tr>
                        <th>
                            9. APAKAH ANDA MENERIMA PEMBAYARAN<br>MENGGUNAKAN METODE LAIN SEPERTI KARTU<br>KREDIT?
                        </th>
                        <td>
                            <button class="toggle-content"><i class="fa-solid fa-chevron-down"></i></button>
                        </td>
                    </tr>
                    <tr class="faq-content" style="display: none;">
                        <td colspan="2">
                            <center>
                                Ya, selain pembayaran dengan kartu kredit, kami juga menerima pembayaran melalui transfer
                                bank dan layanan pembayaran digital tertentu. Silakan hubungi tim dukungan pelanggan kami
                                untuk informasi lebih lanjut.
                                <!-- Jawaban untuk pertanyaan kesembilan -->
                            </center>
                        </td>
                    </tr>
                    <!-- Pertanyaan kesepuluh -->
                    <tr>
                        <th>
                            10. APAKAH ADA OPSI PENGIRIMAN CEPAT UNTUK<br>PESANAN MENDESAK?
                        </th>
                        <td>
                            <button class="toggle-content"><i class="fa-solid fa-chevron-down"></i></button>
                        </td>
                    </tr>
                    <tr class="faq-content" style="display: none;">
                        <td colspan="2">
                            <center>
                                Ya, kami menyediakan opsi pengiriman cepat untuk pesanan mendesak dengan biaya tambahan.
                                Silakan hubungi tim dukungan pelanggan kami untuk mengatur pengiriman cepat Anda.
                                <br><br>
                                Jika Anda memiliki pertanyaan lain atau memerlukan bantuan tambahan, jangan ragu untuk
                                menghubungi tim dukungan pelanggan kami. Terima kasih atas kunjungan Anda!
                                <!-- Jawaban untuk pertanyaan kesepuluh -->
                            </center>
                        </td>
                    </tr>
                </table>
            </center>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const buttons = document.querySelectorAll('.toggle-content');
            buttons.forEach(button => {
                button.addEventListener('click', function() {
                    const contentRow = this.closest('tr').nextElementSibling;
                    if (contentRow.style.display === 'none') {
                        contentRow.style.display = 'table-row';
                        this.innerHTML = '<i class="fa-solid fa-chevron-up"></i>';
                    } else {
                        contentRow.style.display = 'none';
                        this.innerHTML = '<i class="fa-solid fa-chevron-down"></i>';
                    }
                });
            });
        });
    </script>
@endsection
