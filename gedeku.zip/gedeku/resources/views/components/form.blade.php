<div class="form-bottom" style="background-image: url('{{ asset('img/form-bg.png') }}')">
    <!-- Div utama dengan background gambar yang diambil dari path yang disediakan oleh Laravel asset helper -->
    <div class="form-card">
        <!-- Div untuk mengatur tata letak form dalam kartu -->
        <center>
            <!-- Center untuk meratakan isi ke tengah -->
            @if (session()->has('inputMessageSuccess'))
                <!-- Cek apakah session memiliki 'inputMessageSuccess' -->
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <!-- Div untuk menampilkan pesan sukses -->
                    {{ session('inputMessageSuccess') }}
                    <!-- Menampilkan pesan sukses dari session -->
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
                    <!-- Tombol untuk menutup alert -->
                </div>
            @endif
            <form action="/inputMessage" method="POST">
                <!-- Formulir yang mengirim data ke /inputMessage menggunakan metode POST -->
                @csrf
                <!-- Token CSRF untuk keamanan form -->
                <div class="form-row">
                    <!-- Baris form pertama -->
                    <div class="form-group">
                        <!-- Grup form untuk input nama -->
                        <label for="name">Nama</label>
                        <!-- Label untuk input nama -->
                        <input type="text" id="name" required autocomplete="off" name="name">
                        <!-- Input teks untuk nama, wajib diisi dan autocomplete dimatikan -->
                    </div>
                    <div class="form-group">
                        <!-- Grup form untuk input email -->
                        <label for="email">Alamat Email</label>
                        <!-- Label untuk input email -->
                        <input type="email" id="email" required autocomplete="off" name="email">
                        <!-- Input email, wajib diisi dan autocomplete dimatikan -->
                    </div>
                </div>
                <div class="form-row">
                    <!-- Baris form kedua -->
                    <div class="form-group">
                        <!-- Grup form untuk input nomor telepon -->
                        <label for="phone">Nomor Telepon</label>
                        <!-- Label untuk input nomor telepon -->
                        <input type="number" id="phone" required autocomplete="off" name="phone">
                        <!-- Input nomor telepon, wajib diisi dan autocomplete dimatikan -->
                    </div>
                    <div class="form-group">
                        <!-- Grup form untuk input perusahaan -->
                        <label for="company">Perusahaan</label>
                        <!-- Label untuk input perusahaan -->
                        <input type="text" id="company" required autocomplete="off" name="company">
                        <!-- Input teks untuk perusahaan, wajib diisi dan autocomplete dimatikan -->
                    </div>
                </div>
                <div class="form-row">
                    <!-- Baris form ketiga -->
                    <div class="form-group">
                        <!-- Grup form untuk input pesan -->
                        <label for="message">Pesan</label>
                        <!-- Label untuk input pesan -->
                        <input type="text" id="message" required autocomplete="off" name="message">
                        <!-- Input teks untuk pesan, wajib diisi dan autocomplete dimatikan -->
                    </div>
                </div>
                <div class="form-row">
                    <!-- Baris form keempat -->
                    <button type="submit" class="submitForm">Mengirim Pesan</button>
                    <!-- Tombol submit untuk mengirim formulir -->
                </div>
            </form>
        </center>
    </div>
</div>
