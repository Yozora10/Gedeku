@extends('layouts/main')

@section('main')
    <div class="wallpaper" style="background-image: url('{{ asset('img/our-product-bg.png') }}')"></div>
    <!-- Gambar latar belakang untuk halaman produk -->

    <div class="container">
        <center>
            <h1>Online Product Shop</h1>
            <!-- Judul halaman -->
            <p class="ourProductDesc">
                Pagoda Keripik Kari merupakan<br>
                cemilan sekaligus oleh-oleh khas Batam yang<br>
                mana menggunakan bahan baku yang dihasilkan<br>
                dari hasil kekayaan alam daerah seperti<br>
                gonggong, yang mana gonggong sendiri hanya<br>
                berada di perarian Kepulauan Riau, dan<br>
                menggunakan rempah-rempah khas Melayu, yaitu<br>
                kari.
                <!-- Deskripsi produk -->
            </p>

            <div class="product-gallery">
                <!-- Galeri produk -->
                <div class="product-item">
                    <img src="{{ asset('img/prdct1.png') }}" alt="Product" class="product-image">
                </div>
                <div class="product-item">
                    <img src="{{ asset('img/prdct3.png') }}" alt="Product" class="product-image">
                </div>
            </div>
            <!-- Daftar produk -->
            <br><br><br><br>
            <!-- Spasi -->

            <h1>Legalitas Perusahaan</h1>
            <!-- Judul legalitas perusahaan -->
            <br><br><br>
            <table class="legalitas-table">
                <thead>
                    <tr>
                        <th>PIRT</th>
                        <th>HALAL</th>
                        <th>IUMK</th>
                        <th>DOMISILI</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>NO: 2062171010183-19</td>
                        <td>NO: 04100025840318</td>
                        <td>NO: IUMK/65/SGL/V/2018</td>
                        <td>NO: 156/517/SGL/V/2007</td>
                    </tr>
                    <tr>
                        <td>Dikeluarkan oleh Dinas<br>Kesehatan Kota Batam</td>
                        <td>Dikeluarkan oleh LPPOM<br>MUI Batam</td>
                        <td>Dikeluarkan oleh<br>Kecamatan Sagulung</td>
                        <td>Dikeluarkan oleh<br>Kecamatan Sagulung</td>
                    </tr>
                </tbody>
            </table>
            <!-- Tabel legalitas perusahaan -->
        </center>
    </div>
@endsection
