<?php

use App\Http\Controllers\GedekuController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route untuk menampilkan halaman utama
Route::get('/', [GedekuController::class, "home"]);

// Route untuk menampilkan halaman tentang kami
Route::get('/aboutUs', [GedekuController::class, "aboutUs"]);

// Route untuk menampilkan halaman produk kami
Route::get('/ourProduct', [GedekuController::class, "ourProduct"]);

// Route untuk menampilkan halaman ulasan
Route::get('/review', [GedekuController::class, "review"]);

// Route untuk menampilkan halaman pertanyaan umum
Route::get('/faq', [GedekuController::class, "faq"]);

// Route untuk menyimpan pesan yang dikirim oleh pengguna
Route::post('/inputMessage', [GedekuController::class, "inputMessage"]);
